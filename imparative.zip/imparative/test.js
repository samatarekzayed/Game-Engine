
console.log('a'.charCodeAt(0)-97);