import { Abstract_game_engine } from "./Abstract_game_engine";


export class connect4 extends Abstract_game_engine{
    style='height:60px;width:60px;margin:1px;vertical-align: middle;text-align:center;font-size: 25px;box-shadow: #1f59df;background-color:#ffffff;border-radius: 30px;';
    constructor(){
        super();
    }
    createBoard(){
        state=[
        [' ',' ',' ',' ',' ', ' ',' ' ],
        [' ',' ',' ',' ',' ', ' ',' ' ],
        [' ',' ',' ',' ',' ', ' ',' ' ],
        [' ',' ',' ',' ',' ', ' ',' ' ],
        [' ',' ',' ',' ',' ', ' ',' ' ],
        [' ',' ',' ',' ',' ', ' ',' ' ]
       
     ];
        return state;
    }
    takeUserInput(){
        this.takeUserInput1();
    }
    Drawer(state){
        const to_del=document.getElementById("to")
        if (to_del!=null)
        {
            to_del.remove()
        }
        const todel=document.getElementById("to")
        if (todel!=null)
        {
            todel.remove()
        }
        
        const to_be_del=document.getElementById("tablee")
        if (to_be_del!=null){
            to_be_del.remove()
        }
        const tbl = document.createElement("table");
        tbl.style='border:none';
        tbl.setAttribute("id","tablee");  // create table
        const tblBody = document.createElement("tbody"); 
        const row = document.createElement("tr");
        const cell = document.createElement("td");
        cell.style='height:60px;width:60px;margin:1px;vertical-align: middle;text-align:center;font-size: 25px;box-shadow: #1f59df;background-color:#ffffff;';
        row.appendChild(cell)
        for (let i = 0 ;i< state[0].length; i++){
            const cell = document.createElement("td");
            cell.style='height:60px;width:60px;margin:1px;vertical-align: middle;text-align:center;font-size: 25px;box-shadow: #1f59df;background-color:#ffffff;';
            let ascii=i+97
            ascii='&#0'+ascii
            cell.innerHTML=ascii
            row.appendChild(cell);
        }
        tblBody.appendChild(row);
      
        for (let i = 0; i <state.length  ; i++) {// hlf 3la rows el state w el columns kol mara h create row w h3ml append kol mara 
            const row = document.createElement("tr");
            const cell=document.createElement("td");
            cell.style='height:60px;width:60px;margin:1px;vertical-align: middle;text-align:center;font-size: 25px;box-shadow: #1f59df;background-color:#ffffff;';
            cell.innerHTML=i+1;
            row.appendChild(cell);
           
            for (let j = 0; j < state[0].length; j++) { 
               
                const cell = document.createElement("td");
                cell.style=this.style;
                
                if (state[i][j]=='r')
                    cell.style.backgroundColor="#f52b2b";
                else if (state[i][j]=='y')
                    cell.style.backgroundColor="#e1f52b";  
               

                row.appendChild(cell); 
            }
            tblBody.appendChild(row);    
        }
        
        tbl.appendChild(tblBody);// append table body to table nfso 
        document.body.appendChild(tbl); // b append kol dah lel document 
        tbl.style="border-style:solid;background-color:#1f59df;border:10";
       
    }

    Controller (input){
        if (this.isValidLength(input)){
        const {r,c}=this.FindRowCol(input);
        if(this.isCellInBounds(r,c)) {
            if(this.borad[r][c]==null && (r==5|| this.borad[r-1][c]!=' ') ){
                if(this.currentPlayer==1)
                    this.borad[r][c]='r';
                else
                    this.borad[r][c]='y'
            this.swich_turns();

            }
        }
        else
            console.log("choose another place")
    }
    else
        console.log("wrong input")
    }

}
// console.log("ddddddd")
// connect4_game=new connect4();
// connect4_game.Initialize();